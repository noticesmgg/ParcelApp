﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using SharedCore.Utilities;

namespace LinkReader.DataObjects
{
    public class ParcelRecord
    {
        public int Id { get; set; }
        public string ShortParcel { get; set; }
        public string ParcelNumber { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int ZipCode { get; set; }
        public double AskingPrice { get; set; }
        public double UpdatedAskingPrice { get; set; }
        public DateTime? AdDate { get; set; }
        public DateTime? BidOffDate { get; set; }
        public DateTime? LastDateToApply { get; set; }
        public double Acreage { get; set; }
        public int SquareFoot { get; set; }
        public string Dimensions { get; set; }
        public bool HasDemo { get; set; }
        public string PermitStatus { get; set; }
        public String PropertyStatus { get; set; }
        public string PropertyClassification { get; set; }
        public string Source { get; set; } = "Memphis LandBank";
        public string Owner { get; set; }
        public double LandAppraisal { get; set; }
        public double BuildingAppraisal { get; set; }
        public double TotalAppraisal { get; set; }
        public double TotalAssessment { get; set; }
        public string LandUse { get; set; }
        public int? YearBuilt { get; set; }
        public int? Stories { get; set; }
        public int? TotalRooms { get; set; }
        public DateTime? RecentDateOfSale { get; set; }
        public double RecentSalesPrice { get; set; }
        public DateTime? SecondRecentDateOfSale { get; set; }
        public double SecondRecentSalesPrice { get; set; }

        public string PropertyAddress { get; set; }        
        public string AccessorLink { get; set; }
        public string GisLink { get; set; }

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider adding the 'required' modifier or declaring as nullable.
        public ParcelRecord()
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider adding the 'required' modifier or declaring as nullable.
        {
            // Default constructor
        }


        public ParcelRecord(DataRow dr)
        {
            if(dr.Table.Columns.Contains("Id"))
                Id = dr["Id"].ToSafeInt();

            ShortParcel = dr["ShortParcel"].ToSafeString();
            ParcelNumber = dr["ParcelNumber"].ToSafeString();
            Street = dr["Street"].ToSafeString();
            City = dr["City"].ToSafeString();
            State = dr["State"].ToSafeString();
            ZipCode = dr["ZipCode"].ToSafeInt();
            AskingPrice = dr["AskingPrice"].ToSafeDouble();
            UpdatedAskingPrice = dr["UpdatedAskingPrice"].ToSafeDouble();
            AdDate = dr["AdDate"].ToSafeMinNullDate();
            BidOffDate = dr["BidOffDate"].ToSafeMinNullDate();
            LastDateToApply = dr["LastDateToApply"].ToSafeMinNullDate();
            Acreage = dr["Acreage"].ToSafeDouble();
            SquareFoot = dr["SquareFoot"].ToSafeInt();
            Dimensions = dr["Dimensions"].ToSafeString();
            HasDemo = dr["HasDemo"].ToSafeBool();
            PermitStatus = dr["PermitStatus"].ToSafeString();
            PropertyStatus = dr["PropertyStatus"].ToSafeString();
            PropertyClassification = dr["PropertyClassification"].ToSafeString();
            Owner = dr["Owner"].ToSafeString();
            LandAppraisal = dr["LandAppraisal"].ToSafeDouble();
            BuildingAppraisal = dr["BuildingAppraisal"].ToSafeDouble();
            TotalAppraisal = dr["TotalAppraisal"].ToSafeDouble();
            TotalAssessment = dr["TotalAssessment"].ToSafeDouble();
            LandUse = dr["LandUse"].ToSafeString();
            YearBuilt = dr["YearBuilt"].ToSafeInt();
            Stories = dr["Stories"].ToSafeInt();
            TotalRooms = dr["TotalRooms"].ToSafeInt();
            RecentDateOfSale = dr["RecentDateOfSale"].ToSafeMinNullDate();
            RecentSalesPrice = dr["RecentSalesPrice"].ToSafeDouble();
            SecondRecentDateOfSale = dr["SecondRecentDateOfSale"].ToSafeMinNullDate();
            SecondRecentSalesPrice = dr["SecondRecentSalesPrice"].ToSafeDouble();
           
            //PropertyAddress = dr["PropertyAddress"].ToSafeString();
            //AccessorLink = dr["AccessorLink"].ToSafeString();
            //GisLink = dr["GisLink"].ToSafeString();

        }

        public void Normalize()
        {
            ShortParcel = ShortParcel.Trim();
            ParcelNumber = ParcelNumber.Trim();
            Street = Street.Trim();
            City = City.Trim();
            State = State.Trim();
            SquareFoot = SquareFoot;
            Dimensions = Dimensions.Trim();
            PermitStatus = PermitStatus.Trim();
            PropertyStatus = PropertyStatus.Trim();
            PropertyClassification = PropertyClassification.Trim();
            Owner = Owner.Trim();
            LandUse = LandUse.Trim();
            if (YearBuilt == 0)
                YearBuilt = null;
            if (Stories == 0)
                Stories = null;
            if (TotalRooms == 0)
                TotalRooms = null;

            if(AdDate.HasValue && AdDate.Value < Helper.MinDate)
                AdDate = null;
            if (BidOffDate.HasValue && BidOffDate.Value < Helper.MinDate)
                BidOffDate = null;
            if (LastDateToApply.HasValue && LastDateToApply.Value < Helper.MinDate)
                LastDateToApply = null;

            if (RecentDateOfSale.HasValue && RecentDateOfSale.Value < Helper.MinDate)
                RecentDateOfSale = null;
            if (SecondRecentDateOfSale.HasValue && SecondRecentDateOfSale.Value < Helper.MinDate)
                SecondRecentDateOfSale = null;

        }

        public bool IsEqual(ParcelRecord other)
        {
            if (other == null)
                return false;

            return ShortParcel == other.ShortParcel &&
                   ParcelNumber == other.ParcelNumber &&
                   Street == other.Street &&
                   City == other.City &&
                   State == other.State &&
                   ZipCode == other.ZipCode &&
                   AskingPrice == other.AskingPrice &&
                   UpdatedAskingPrice == other.UpdatedAskingPrice &&
                   AdDate == other.AdDate &&
                   BidOffDate == other.BidOffDate &&
                   LastDateToApply == other.LastDateToApply &&
                   Acreage == other.Acreage &&
                   SquareFoot == other.SquareFoot &&
                   Dimensions == other.Dimensions &&
                   HasDemo == other.HasDemo &&
                   PermitStatus == other.PermitStatus &&
                   PropertyStatus == other.PropertyStatus &&
                   PropertyClassification == other.PropertyClassification &&
                   Owner == other.Owner &&
                   LandAppraisal == other.LandAppraisal &&
                   BuildingAppraisal == other.BuildingAppraisal &&
                   TotalAppraisal == other.TotalAppraisal &&
                   TotalAssessment == other.TotalAssessment &&
                   LandUse == other.LandUse &&
                   YearBuilt == other.YearBuilt &&
                   Stories == other.Stories &&
                   TotalRooms == other.TotalRooms &&
                   RecentDateOfSale == other.RecentDateOfSale &&
                   RecentSalesPrice == other.RecentSalesPrice &&
                   SecondRecentDateOfSale == other.SecondRecentDateOfSale &&
                   SecondRecentSalesPrice == other.SecondRecentSalesPrice;
        }


        //Save into LandBank table if there are any changes, if its new insert, else update
        public bool PersistToDB()
        {
            try
            {
                var db = SharedCore.DB.Database.Instance.DB;

                if (Id > 0)
                {
                    // Inline UPDATE query
                    string updateQuery = $@"
                        UPDATE LandBank SET
                            ShortParcel = '{ShortParcel.Replace("'", "''")}',
                            ParcelNumber = '{ParcelNumber.Replace("'", "''")}',
                            Street = '{Street.Replace("'", "''")}',
                            City = '{City.Replace("'", "''")}',
                            State = '{State.Replace("'", "''")}',
                            ZipCode = {ZipCode},
                            AskingPrice = {AskingPrice},
                            UpdatedAskingPrice = {UpdatedAskingPrice},
                            AdDate = {(AdDate.HasValue ? $"'{AdDate.Value.ToDateForDBFormat()}'" : "NULL")},
                            BidOffDate = {(BidOffDate.HasValue ? $"'{BidOffDate.Value.ToDateForDBFormat()}'" : "NULL")},
                            LastDateToApply = {(LastDateToApply.HasValue ? $"'{LastDateToApply.Value.ToDateForDBFormat()}'" : "NULL")},
                            Acreage = {Acreage},
                            SquareFoot = {SquareFoot},
                            Dimensions = '{Dimensions.Replace("'", "''")}',
                            HasDemo = {(HasDemo ? 1 : 0)},
                            PermitStatus = '{PermitStatus.Replace("'", "''")}',
                            PropertyStatus = '{PropertyStatus.Replace("'", "''")}',
                            PropertyClassification = '{PropertyClassification.Replace("'", "''")}',
                            Owner = '{Owner.Replace("'", "''")}',
                            LandAppraisal = {LandAppraisal},
                            BuildingAppraisal = {BuildingAppraisal},
                            TotalAppraisal = {TotalAppraisal},
                            TotalAssessment = {TotalAssessment},
                            LandUse = '{LandUse.Replace("'", "''")}',
                            YearBuilt = {(YearBuilt.HasValue ? YearBuilt.ToString() : "NULL")},
                            Stories = {(Stories.HasValue ? Stories.ToString() : "NULL")},
                            TotalRooms = {(TotalRooms.HasValue ? TotalRooms.ToString() : "NULL")},
                            RecentDateOfSale = {(RecentDateOfSale.HasValue ? $"'{RecentDateOfSale.Value.ToDateForDBFormat()}'" : "NULL")},
                            RecentSalesPrice = {RecentSalesPrice},
                            SecondRecentDateOfSale = {(SecondRecentDateOfSale.HasValue ? $"'{SecondRecentDateOfSale.Value.ToDateForDBFormat()}'" : "NULL")},
                            SecondRecentSalesPrice = {SecondRecentSalesPrice},
                            UpdatedDate = GetDate(),
                            UpdatedBy = 'System'

                        WHERE Id = {Id}";

                    db.Execute(updateQuery);
                }
                else
                {
                    // Inline INSERT query
                    string insertQuery = $@"
                        INSERT INTO LandBank
                        (ShortParcel, ParcelNumber, Street, City, State, ZipCode, AskingPrice, UpdatedAskingPrice, AdDate, BidOffDate, LastDateToApply, Acreage, SquareFoot, Dimensions, HasDemo, 
                            PermitStatus, PropertyStatus, PropertyClassification, Owner, LandAppraisal, BuildingAppraisal, TotalAppraisal, TotalAssessment, LandUse, YearBuilt, Stories, TotalRooms, 
                            RecentDateOfSale, RecentSalesPrice, SecondRecentDateOfSale, SecondRecentSalesPrice, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy, source)
                        VALUES
                        (
                            '{ShortParcel.Replace("'", "''")}',
                            '{ParcelNumber.Replace("'", "''")}',
                            '{Street.Replace("'", "''")}',
                            '{City.Replace("'", "''")}',
                            '{State.Replace("'", "''")}',
                            {ZipCode},
                            {AskingPrice},
                            {UpdatedAskingPrice},
                            {(AdDate.HasValue ? $"'{AdDate:yyyy-MM-dd HH:mm:ss}'" : "NULL")},
                            {(BidOffDate.HasValue ? $"'{BidOffDate:yyyy-MM-dd HH:mm:ss}'" : "NULL")},
                            {(LastDateToApply.HasValue ? $"'{LastDateToApply:yyyy-MM-dd HH:mm:ss}'" : "NULL")},
                            {Acreage},
                            {SquareFoot},
                            '{Dimensions.Replace("'", "''")}',
                            {(HasDemo ? 1 : 0)},
                            '{PermitStatus.Replace("'", "''")}',
                            '{PropertyStatus.Replace("'", "''")}',
                            '{PropertyClassification.Replace("'", "''")}',
                            '{Owner.Replace("'", "''")}',
                            {LandAppraisal},
                            {BuildingAppraisal},
                            {TotalAppraisal},
                            {TotalAssessment},
                            '{LandUse.Replace("'", "''")}',
                            {(YearBuilt.HasValue ? YearBuilt.ToString() : "NULL")},
                            {(Stories.HasValue ? Stories.ToString() : "NULL")},
                            {(TotalRooms.HasValue ? TotalRooms.ToString() : "NULL")},
                            {(RecentDateOfSale.HasValue ? $"'{RecentDateOfSale:yyyy-MM-dd HH:mm:ss}'" : "NULL")},
                            {RecentSalesPrice},
                            {(SecondRecentDateOfSale.HasValue ? $"'{SecondRecentDateOfSale:yyyy-MM-dd HH:mm:ss}'" : "NULL")},
                            {SecondRecentSalesPrice},
                            GetDate(),
                            'System',
                            GetDate(),
                            'System',
                            '{Source.Replace("'", "''")}'
                        );
                        SELECT CAST(SCOPE_IDENTITY() as int)";

                    Id = db.QuerySingle<int>(insertQuery);
                }

                return true;
            }
            catch (Exception ex)
            {
                Logger.Error($"Error in PersistToDB for ParcelRecord: {ParcelNumber} {Street} - " + ex.Message);
                return false;
            }
        }
    }
}
