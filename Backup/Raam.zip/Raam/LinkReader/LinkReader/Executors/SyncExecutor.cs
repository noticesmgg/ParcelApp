﻿using CsvHelper;
using CsvHelper.Configuration;
using LinkReader.DataObjects;
using SharedCore.DB;
using SharedCore.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkReader.Executors
{
    internal class SyncExecutor
    {

       public readonly Dictionary<string, ParcelRecord> Cache = new Dictionary<string, ParcelRecord>(StringComparer.CurrentCultureIgnoreCase);

        public SyncExecutor() {
            LoadCache();
        }
       public void LoadCache()
        {
            try
            {
                Cache.Clear();

                var sql = "Select * from LandBank";
                var dt = Database.Instance.DB.GetRecords(sql);
                foreach (DataRow row in dt.Rows)
                {
                    var record = new ParcelRecord(row);
                    record.Normalize();

                    if (!Cache.ContainsKey(record.ParcelNumber))
                    {
                        Cache.Add(record.ParcelNumber, record);
                    }
                }

            }
            catch (Exception ex)
            {
                Logger.Error($"Exception while loading cache from DB. Details : {ex.StackTrace} {ex.Message}");
            }
        }
        public void Save(String filePath)
        {
			try
			{

                var dt = filePath.GetDataTable();
    
                foreach (DataRow dr in dt.Rows)
                {
                    var record = new ParcelRecord(dr);

                    if (record == null)
                        continue;

                    record.Normalize();

                    if (Cache.ContainsKey(record.ParcelNumber))
                    {
                        var cachedRecord = Cache[record.ParcelNumber];
                        if (!record.IsEqual(cachedRecord))
                        {
                            // Update existing record
                            record.Id = cachedRecord.Id; // Ensure the ID is set for update
                            if (record.PersistToDB())
                            {
                                Console.WriteLine($"Updated record for ParcelNumber: {record.ParcelNumber}");
                                Cache[record.ParcelNumber] = record; // Update cache
                            }
                        }
                    }
                    else
                    {
                        // New record
                        if (record.PersistToDB())
                        {
                            Console.WriteLine($"Inserted new record for ParcelNumber: {record.ParcelNumber}");
                            Cache.Add(record.ParcelNumber, record); // Add to cache
                        }
                    }

                }

            }
            catch (Exception ex)
			{
                Console.WriteLine($"Exception while saving records to DB. Details : {ex.StackTrace} {ex.Message}");
			}
        }
    }
}
