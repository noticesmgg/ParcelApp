﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkReader
{
    internal class Helper
    {
        public static DateTime MinDate = new DateTime(1900, 1, 1);
    }
}
