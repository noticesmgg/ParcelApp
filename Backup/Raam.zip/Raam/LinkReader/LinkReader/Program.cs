﻿using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using System;
using System.IO;
using System.Linq;
using CsvHelper.Configuration;
using CsvHelper;
using System.Globalization;
using SharedCore.Utilities;
using LinkReader.DataObjects;
using LinkReader.Executors;

namespace LinkReader
{
   
    public class InputRecord
    {
        public string ParcelNumber { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public string PropertyClassification { get; set; }
        public String AdDate { get; set; }
        public string AskingPrice { get; set; }
        public String BidOffDate {  get; set; }
        public String LastDayToApply { get; set; }
        public String PropertyStatus { get; set;  }
        public string SizeInAcres { get; set; }
        public string UpdatedAskingPrice { get;set; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            
            string outputPath = @"C:\Temp\LinkOutputToSave.csv";
            var syncer = new SyncExecutor();
            syncer.Save(outputPath);
            return;

            string csvFilePath = @"C:\Temp\Link0115.csv"; // Update with your file path
            if (!File.Exists(csvFilePath))
            {
                Console.WriteLine("CSV file not found.");
                return;
            }

            var config = new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HasHeaderRecord = true,
                PrepareHeaderForMatch = args => args.Header?.Replace(" ", "") // Removes all spaces from header names
            };

            List<ParcelRecord> records = new List<ParcelRecord>();
            List<InputRecord> inputRecords = new List<InputRecord>();
            List<InputRecord> errorRecords = new List<InputRecord>();
            using (var reader = new StreamReader(csvFilePath))
            using (var csv = new CsvReader(reader, config))
            {
                inputRecords = csv.GetRecords<InputRecord>().ToList();
            }

            //Exclude inputRecords where PropertyStatus Field is not equal to "SALE PENDING - CC" 
            inputRecords = inputRecords.Where(r => r.PropertyStatus != "SALE PENDING - CC").ToList();

            //Now Exclude inputRecords where LastDayToApply field has any dates that is before today. Leave the blank dates though.
            inputRecords = inputRecords.Where(r => string.IsNullOrWhiteSpace(r.LastDayToApply) || r.LastDayToApply.ToSafeDate() >= DateTime.Today).ToList();

            //https://www.assessormelvinburgess.com/realPropertyDetails?StreetNumber=693&StreetName=barrett&FirstName=&LastName=&ParcelID=&Business=&active=address&Page=property


            //var htmlParser = new PDFParser();
            //htmlParser.Run(inputRecords);
            //return;

            using var driver = new ChromeDriver();
            int count = 0;
            foreach (var r in inputRecords)
            {
                count++;
                try
                {
                    var link = GetLink(r.ParcelNumber);

                    if (link == null)
                    {
                        errorRecords.Add(r);
                        continue;
                    }

                    var record = new ParcelRecord
                    {
                        ParcelNumber = r.ParcelNumber,
                        AccessorLink = link,
                        AdDate = r.AdDate.ToSafeDate(),
                        Street = r.Street,
                        AskingPrice = r.AskingPrice.ToSafeDouble(),
                        BidOffDate = r.BidOffDate.ToSafeDate(),
                        City = r.City,
                        UpdatedAskingPrice = r.UpdatedAskingPrice.ToSafeDouble(),
                        ZipCode = r.PostalCode.ToSafeInt(),
                        State = r.State,
                        PropertyClassification = r.PropertyClassification,
                        LastDateToApply = r.LastDayToApply.ToSafeDate(),
                        PropertyStatus = r.PropertyStatus,
                        Acreage = r.SizeInAcres.ToSafeDouble(),   
                        ShortParcel = GetParcelNumber(r.ParcelNumber),
                    };

                    driver.Navigate().GoToUrl(record.AccessorLink);

                    // Extract Property Address
                    var propertyAddressElement = driver.FindElements(By.XPath("//td[normalize-space(text())='Property Address:']/following-sibling::td")).FirstOrDefault();
                    record.PropertyAddress = propertyAddressElement?.Text.Trim() ?? "";

                    // Extract Lot Dimensions
                    var lotDimensionsElement = driver.FindElements(By.XPath("//td[normalize-space(text())='Lot Dimensions :']/following-sibling::td")).FirstOrDefault();
                    record.Dimensions = lotDimensionsElement?.Text.Trim() ?? "";

                    var ownerNameElement = driver.FindElements(By.XPath("//td[normalize-space(text())='Owner Name :']/following-sibling::td")).FirstOrDefault();
                    record.Owner = ownerNameElement?.Text.Trim() ?? "";

                    var landSqFootageElement = driver.FindElements(By.XPath("//td[normalize-space(text())='Land Square Footage :']/following-sibling::td")).FirstOrDefault();
                    var sqFoot = landSqFootageElement?.Text.Trim() ?? "";

                    // Convert square footage to integer, and if the value overflows the int max limit, then take the int maxValue
                    record.SquareFoot = sqFoot.ToSafeInt();

                    var gisLink = GetGISLink(r.ParcelNumber);
                    record.GisLink = gisLink ?? "";

                    //Appraisal and Assessment Information  Land Appraisal: Building Appraisal: Total Appraisal: Total Assessment:
                    var divLinks = driver.FindElements(By.LinkText("Appraisal and Assessment Information")).FirstOrDefault();
                    if (divLinks == null)
                    {
                        Console.WriteLine($"Permits link not found for {record.AccessorLink}");
                        continue;
                    }
                    SafeClick(driver, divLinks);
                    //divLinks.Click();

                    var buildingAppraisal = driver.FindElements(By.XPath("//td[normalize-space(text())='Building Appraisal:']/following-sibling::td")).FirstOrDefault();
                    record.BuildingAppraisal = buildingAppraisal?.Text.Replace("$", "").Replace(",", "").Trim().ToSafeDouble() ?? 0;

                    var landAppraisal = driver.FindElements(By.XPath("//td[normalize-space(text())='Land Appraisal:']/following-sibling::td")).FirstOrDefault();
                    record.LandAppraisal = landAppraisal?.Text.Replace("$", "").Replace(",", "").Trim().ToSafeDouble() ?? 0;

                    var totalAppraisal = driver.FindElements(By.XPath("//td[normalize-space(text())='Total Appraisal:']/following-sibling::td")).FirstOrDefault();
                    record.TotalAppraisal = totalAppraisal?.Text.Replace("$", "").Replace(",", "").Trim().ToSafeDouble() ?? 0;

                    var totalAssessment = driver.FindElements(By.XPath("//td[normalize-space(text())='Total Assessment:']/following-sibling::td")).FirstOrDefault();
                    record.TotalAssessment = totalAssessment?.Text.Replace("$", "").Replace(",", "").Trim().ToSafeDouble() ?? 0;

                    SafeClick(driver, divLinks);
                    //divLinks.Click();

                    //Improvement Details  Land Use Year Built Stories: Total Rooms: Stories:
                    divLinks = driver.FindElements(By.LinkText("Improvement Details")).FirstOrDefault();
                    if (divLinks == null)
                    {
                        Console.WriteLine($"Permits link not found for {record.AccessorLink}");
                        continue;
                    }
                    SafeClick(driver, divLinks);
                    //divLinks.Click();


                    var yearBuilt = driver.FindElements(By.XPath("//td[normalize-space(text())='Year Built:']/following-sibling::td")).FirstOrDefault();
                    record.YearBuilt = yearBuilt?.Text.Replace("$", "").Replace(",", "").Trim().ToSafeInt() ?? 0;

                    var landUse = driver.FindElements(By.XPath("//td[normalize-space(text())='Land Use:']/following-sibling::td")).FirstOrDefault(); ;
                    record.LandUse = landUse?.Text.Trim().Replace("-", "") ?? "";

                    var stories = driver.FindElements(By.XPath("//td[normalize-space(text())='Stories:']/following-sibling::td")).FirstOrDefault();
                    record.Stories = stories?.Text.Replace("$", "").Replace(",", "").Trim().ToSafeInt() ?? 0;

                    var totalRooms = driver.FindElements(By.XPath("//td[normalize-space(text())='Total Rooms:']/following-sibling::td")).FirstOrDefault();
                    record.TotalRooms = totalRooms?.Text.Replace("$", "").Replace(",", "").Trim().ToSafeInt() ?? 0;

                    SafeClick(driver, divLinks);

                    // Wait for the page to load and find the "Permits" section/link
                    divLinks = driver.FindElements(By.LinkText("Permits")).FirstOrDefault();
                    if (divLinks == null)
                    {
                        Console.WriteLine($"Permits link not found for {record.AccessorLink}");
                        continue;
                    }

                    SafeClick(driver, divLinks);

                    // Wait for the section to load (adjust selector as needed)
                    var rows = driver.FindElements(By.XPath("//table//tr"));
                    bool hasPermitRows = rows.Any(row => row.Text.Contains("Date of Permit", StringComparison.OrdinalIgnoreCase));
                    bool foundDemo = rows.Any(row => row.Text.Contains("Dem", StringComparison.OrdinalIgnoreCase));

                    if (hasPermitRows)
                    {
                        record.HasDemo = true;

                        if (!foundDemo)
                        {
                            record.PermitStatus = "Other";
                            record.HasDemo = false;
                        }
                    }
                    else
                    {
                        record.HasDemo = false;
                    }

                    SafeClick(driver, divLinks);

                    //Sales History  Date of Sale: Sales Price: Deed Type:                    

                    divLinks = driver.FindElements(By.LinkText("Sales History")).FirstOrDefault();
                    if (divLinks == null)
                    {
                        Console.WriteLine($"Permits link not found for {record.AccessorLink}");
                        continue;
                    }

                    SafeClick(driver, divLinks);


                    //var wait = new OpenQA.Selenium.Support.UI.WebDriverWait(driver, TimeSpan.FromSeconds(10));
                    //var salesTable = wait.Until(drv => drv.FindElement(By.XPath("//table[@class='table table-borderless']/tbody[@id='salesBody']")));
                    var salesTable = driver.FindElement(By.XPath("//table[@class='table table-borderless']/tbody[@id='salesBody']"));

                    if (salesTable != null && salesTable.FindElements(By.TagName("tr")).Count != 0)
                    {


                        // Get the first row
                        var firstRow = salesTable.FindElements(By.TagName("tr")).FirstOrDefault();
                        if (firstRow != null)
                        {
                            var cells = firstRow.FindElements(By.TagName("td"));
                            if (cells.Count >= 2)
                            {
                                var firstDate = cells[0]?.Text.Trim() ?? "";
                                var firstSalesPrice = cells[1]?.Text.Trim() ?? "0";
                                record.RecentDateOfSale = firstDate.ToSafeDate();
                                record.RecentSalesPrice = firstSalesPrice.Replace("$", "").Replace(",", "").Trim().ToSafeDouble();
                            }
                        }

                        if (salesTable.FindElements(By.TagName("tr")).Count >= 2)
                        {
                            var secondRow = salesTable.FindElements(By.TagName("tr")).ElementAtOrDefault(1);

                            if (secondRow != null)
                            {
                                var cells = secondRow.FindElements(By.TagName("td"));
                                if (cells.Count >= 2)
                                {
                                    var secondDate = cells[0]?.Text.Trim() ?? "";
                                    var secondSalesPrice = cells[1]?.Text.Trim() ?? "0";
                                    record.SecondRecentDateOfSale = secondDate.ToSafeDate();
                                    record.SecondRecentSalesPrice = secondSalesPrice.Replace("$", "").Replace(",", "").Trim().ToSafeDouble();
                                }
                            }
                        }
                    }

                    records.Add(record);
                    //bool foundDemo = rows.Any(row => row.Text.Contains("Date of Permit", StringComparison.OrdinalIgnoreCase));

                    Console.WriteLine($"{count} - {records.Count} - {record.ParcelNumber} - {record.PropertyAddress}: Demo {foundDemo}");
                    System.Threading.Thread.Sleep(20);
                }
                catch (Exception ex)
                {
                    errorRecords.Add(r);
                    Console.WriteLine($"Error processing {r.ParcelNumber}: {ex.Message}");
                }
            }

            driver.Quit();

            // Write updated records back to CSV
            using (var writer = new StreamWriter(@"C:\Temp\LinkOutput0115.csv"))
            using (var csv = new CsvWriter(writer, config))
            {
                csv.WriteHeader<ParcelRecord>();
                csv.NextRecord();
                foreach (var record in records)
                {
                    csv.WriteRecord(record);
                    csv.NextRecord();
                }
            }

            // Write error records back to CSV
            using (var writer = new StreamWriter(@"C:\Temp\LinkErrors0115.csv"))
            using (var csv = new CsvWriter(writer, config))
            {
                csv.WriteHeader<InputRecord>();
                csv.NextRecord();
                foreach (var record in errorRecords)
                {
                    csv.WriteRecord(record);
                    csv.NextRecord();
                }
            }
        }

        private static void SafeClick(IWebDriver driver, IWebElement element)
        {
            System.Threading.Thread.Sleep(500);
            var wait = new OpenQA.Selenium.Support.UI.WebDriverWait(driver, TimeSpan.FromSeconds(5));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(element));
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView({block: 'center'});", element);
            element.Click();
        }

        static List<string>? FormatParcelNumber(string input)
        {
            if (input.Length < 12)
                return null;

            var result = new List<string>();
            result.Add(input.Substring(0, 6));
            
            var secondPart = input.Substring(input.Length - 6);
            if(secondPart.EndsWith("0"))
                secondPart = secondPart.Substring(0, secondPart.Length - 1);

            result.Add(secondPart);

            return result;
        }
            

        static string GetLink(String input)
        {
            var items = FormatParcelNumber(input);

            if(items == null || items.Count < 2)
                return string.Empty;

            return $"https://www.assessormelvinburgess.com/propertyDetails?IR=true&parcelid={items[0]}%20%20{items[1]}";
        }

        static string GetParcelNumber(String input)
        {
            var items = FormatParcelNumber(input);

            if (items == null || items.Count < 2)
                return string.Empty;

            return $"{items[0]}  {items[1]}";
        }

        static string GetGISLink(String input)
        {
            var items = FormatParcelNumber(input);

            if (items == null || items.Count < 2)
                return string.Empty;
           
            return $" https://www.assessormelvinburgess.com/gis?parcelid={items[0]}%20%20{items[1]}";
        }

    }
}
